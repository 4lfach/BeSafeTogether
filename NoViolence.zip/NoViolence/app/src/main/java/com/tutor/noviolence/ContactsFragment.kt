package com.tutor.noviolence

import androidx.fragment.app.Fragment

class ContactsFragment : Fragment(R.layout.fragment_contacts) {
}