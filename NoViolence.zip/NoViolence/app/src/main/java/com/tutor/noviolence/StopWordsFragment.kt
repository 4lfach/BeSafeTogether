package com.tutor.noviolence

import androidx.fragment.app.Fragment

class StopWordsFragment : Fragment(R.layout.fragment_stopwords) {

}